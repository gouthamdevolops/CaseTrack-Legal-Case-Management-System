
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/casetrack", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const User = mongoose.model("User", new mongoose.Schema({
  email: String,
  password: String,
}));

const Case = mongoose.model("Case", new mongoose.Schema({
  title: String,
  status: String,
}));

app.post("/api/login", async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(401).send("Invalid");

  const isMatch = await bcrypt.compare(req.body.password, user.password);
  if (!isMatch) return res.status(401).send("Invalid");

  const token = jwt.sign({ id: user._id }, "secret");
  res.json({ token });
});

app.get("/api/cases", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(403).send("No token");

  const token = authHeader.split(" ")[1];
  try {
    jwt.verify(token, "secret");
    const cases = await Case.find();
    res.json(cases);
  } catch {
    res.status(401).send("Unauthorized");
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));
