# CaseTrack Backend
Node.js + Express API for case management.