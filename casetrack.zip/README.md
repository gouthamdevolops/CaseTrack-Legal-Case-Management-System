# CaseTrack – Legal Case Management System

## Stack
- Frontend: React
- Backend: Node.js + Express
- Database: MongoDB

## Setup
1. Run MongoDB locally.
2. In `/server`, run `npm install` and `node server.js`.
3. In `/client`, run `npm install` and `npm start`.