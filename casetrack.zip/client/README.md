# CaseTrack Frontend
React-based UI for legal case tracking system.