
import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [cases, setCases] = useState([]);

  useEffect(() => {
    const fetchCases = async () => {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/api/cases", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCases(res.data);
    };
    fetchCases();
  }, []);

  return (
    <div>
      <h2>Case Dashboard</h2>
      <ul>
        {cases.map((c) => (
          <li key={c._id}>{c.title} — {c.status}</li>
        ))}
      </ul>
    </div>
  );
}
